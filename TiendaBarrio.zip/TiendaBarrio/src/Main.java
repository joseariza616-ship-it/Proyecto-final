import tienda.vista.VentanaLogin;
import tienda.controlador.Coordinador;

public class Main {
    public static void main(String[] args) {
        java.awt.EventQueue.invokeLater(() -> {
            VentanaLogin v = new VentanaLogin();
            new Coordinador(v);
            v.setVisible(true);
        });
    }
}
