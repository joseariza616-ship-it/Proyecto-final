package tienda.vista;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;

public class VentanaMenu extends JFrame {
    private JButton btnVer, btnGestion, btnReporte, btnCerrarSesion;

    public VentanaMenu() {
        setTitle("Sistema POS - Menú");
        setSize(350, 550);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        JLabel title = new JLabel("PANEL PRINCIPAL", SwingConstants.CENTER);
        title.setFont(new Font("Segoe UI", Font.BOLD, 22));
        title.setBorder(new EmptyBorder(30,0,20,0));
        add(title, BorderLayout.NORTH);

        JPanel pnl = new JPanel(new GridLayout(4, 1, 20, 20));
        pnl.setBorder(new EmptyBorder(20, 40, 40, 40));
        pnl.setBackground(Color.WHITE);

        btnVer = crearBoton("CATÁLOGO / VENTA", new Color(46, 204, 113));
        btnGestion = crearBoton("GESTIÓN INVENTARIO", new Color(52, 152, 219));
        btnReporte = crearBoton("REPORTES", new Color(155, 89, 182));
        btnCerrarSesion = crearBoton("SALIR", new Color(231, 76, 60));

        pnl.add(btnVer); pnl.add(btnGestion); pnl.add(btnReporte); pnl.add(btnCerrarSesion);
        add(pnl, BorderLayout.CENTER);
        setLocationRelativeTo(null);
    }

    private JButton crearBoton(String t, Color c) {
        JButton b = new JButton(t);
        b.setBackground(c);
        b.setForeground(Color.WHITE);
        b.setFont(new Font("Segoe UI", Font.BOLD, 13));
        b.setFocusPainted(false);
        return b;
    }

    public JButton getBtnVer() { return btnVer; }
    public JButton getBtnGestion() { return btnGestion; }
    public JButton getBtnReporte() { return btnReporte; }
    public JButton getBtnCerrarSesion() { return btnCerrarSesion; }
}