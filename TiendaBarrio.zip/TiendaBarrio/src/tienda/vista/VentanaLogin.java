package tienda.vista;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;

public class VentanaLogin extends JFrame {
    private JTextField txtUsuario;
    private JPasswordField txtClave;
    private JButton btnEntrar;

    public VentanaLogin() {
        setTitle("Acceso al Sistema");
        setSize(400, 300);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        //Panel principal
        JPanel panelPrincipal = new JPanel(new GridBagLayout());
        panelPrincipal.setBackground(new Color(240, 244, 248));
        panelPrincipal.setBorder(BorderFactory.createCompoundBorder(
                new EmptyBorder(20, 20, 20, 20),
                BorderFactory.createTitledBorder("Iniciar Sesión")
        ));

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        //Usuario
        gbc.gridx = 0; gbc.gridy = 0;
        panelPrincipal.add(new JLabel("Usuario:"), gbc);
        
        txtUsuario = new JTextField(15);
        txtUsuario.setPreferredSize(new Dimension(0, 30));
        gbc.gridx = 1;
        panelPrincipal.add(txtUsuario, gbc);

        //Clave
        gbc.gridx = 0; gbc.gridy = 1;
        panelPrincipal.add(new JLabel("Contraseña:"), gbc);
        
        txtClave = new JPasswordField(15);
        txtClave.setPreferredSize(new Dimension(0, 30));
        gbc.gridx = 1;
        panelPrincipal.add(txtClave, gbc);

        btnEntrar = new JButton("Ingresar");
        btnEntrar.setBackground(new Color(52, 152, 219));
        btnEntrar.setForeground(Color.WHITE);
        btnEntrar.setFont(new Font("Tahoma", Font.BOLD, 13));
        btnEntrar.setFocusPainted(false);
        btnEntrar.setCursor(new Cursor(Cursor.HAND_CURSOR));
        
        gbc.gridx = 0; gbc.gridy = 2;
        gbc.gridwidth = 2;
        gbc.insets = new Insets(20, 10, 10, 10);
        panelPrincipal.add(btnEntrar, gbc);

        add(panelPrincipal);

        //navegación con ENTER
        txtUsuario.addKeyListener(new KeyAdapter() {
            @Override
            public void keyPressed(KeyEvent e) {
                if (e.getKeyCode() == KeyEvent.VK_ENTER) {
                    txtClave.requestFocus(); //Pasa a contraseña
                }
            }
        });

        txtClave.addKeyListener(new KeyAdapter() {
            @Override
            public void keyPressed(KeyEvent e) {
                if (e.getKeyCode() == KeyEvent.VK_ENTER) {
                    btnEntrar.doClick(); //Ejecuta el ingreso
                }
            }
        });
    }

    //Getters necesarios para el Coordinador
    public String getUsuario() { return txtUsuario.getText(); }
    public String getClave() { return new String(txtClave.getPassword()); }
    public JButton getBtnEntrar() { return btnEntrar; }
}