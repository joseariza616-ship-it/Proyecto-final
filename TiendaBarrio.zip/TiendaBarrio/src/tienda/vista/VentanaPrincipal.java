package tienda.vista;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;

public class VentanaPrincipal extends JFrame {
    private JTable tablaInventario;
    private DefaultTableModel modeloTabla;
    private JTextField txtNombre, txtPrecio, txtStock;
    private JButton btnAgregar, btnCesta, btnFinalizar, btnGuardar, btnVolver;
    private JPanel panelFormulario;

    public VentanaPrincipal() {
        setTitle("Gestión de Tienda");
        setSize(800, 600);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        setLayout(new BorderLayout());

        //Añadir nuevo producto
        panelFormulario = new JPanel(new GridLayout(2, 4, 10, 10));
        panelFormulario.setBorder(BorderFactory.createTitledBorder("Datos del Producto Nuevo"));
        panelFormulario.setBackground(new Color(236, 240, 241));

        panelFormulario.add(new JLabel("Nombre:"));
        txtNombre = new JTextField();
        panelFormulario.add(txtNombre);

        panelFormulario.add(new JLabel("Precio:"));
        txtPrecio = new JTextField();
        panelFormulario.add(txtPrecio);

        panelFormulario.add(new JLabel("Stock Inicial:"));
        txtStock = new JTextField();
        panelFormulario.add(txtStock);

        btnAgregar = new JButton("Añadir al Almacén");
        btnAgregar.setBackground(new Color(46, 204, 113));
        btnAgregar.setForeground(Color.WHITE);
        panelFormulario.add(btnAgregar);

        add(panelFormulario, BorderLayout.NORTH);

        //Tabla
        String[] columnas = {"ID", "Producto", "Precio", "Stock"};
        modeloTabla = new DefaultTableModel(columnas, 0) {
            @Override
            public boolean isCellEditable(int row, int column) { return false; }
        };
        tablaInventario = new JTable(modeloTabla);
        add(new JScrollPane(tablaInventario), BorderLayout.CENTER);

        //Acciones
        JPanel panelAcciones = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        panelAcciones.setBackground(new Color(52, 73, 94));

        btnCesta = new JButton("Añadir a Cesta");
        btnCesta.setBackground(new Color(52, 152, 219));
        btnCesta.setForeground(Color.WHITE);

        btnFinalizar = new JButton("Finalizar Venta / Ver Cesta");
        btnFinalizar.setBackground(new Color(155, 89, 182));
        btnFinalizar.setForeground(Color.WHITE);

        btnGuardar = new JButton("Guardar Inventario");
        btnGuardar.setBackground(new Color(241, 196, 15));
        btnGuardar.setForeground(Color.BLACK);

        btnVolver = new JButton("Volver al Menú");
        btnVolver.setBackground(new Color(231, 76, 60));
        btnVolver.setForeground(Color.WHITE);

        panelAcciones.add(btnCesta);
        panelAcciones.add(btnFinalizar);
        panelAcciones.add(btnGuardar);
        panelAcciones.add(btnVolver);

        add(panelAcciones, BorderLayout.SOUTH);
        setLocationRelativeTo(null);
    }
    
    public void configurarModo(boolean soloLectura) {
        panelFormulario.setVisible(!soloLectura);
        btnGuardar.setVisible(!soloLectura);
        btnCesta.setVisible(true); 

        if (soloLectura) {
            btnCesta.setText("Añadir a Cesta");
            btnFinalizar.setVisible(true);
        } else {
            //Reabastecer
            btnCesta.setText("REABASTECER SELECCIONADO");
            btnFinalizar.setVisible(false);
        }
    }

    public void limpiarCampos() {
        txtNombre.setText("");
        txtPrecio.setText("");
        txtStock.setText("");
    }

    // Getters
    public DefaultTableModel getModeloTabla() { return modeloTabla; }
    public JTable getTablaInventario() { return tablaInventario; }
    public JButton getBtnAgregar() { return btnAgregar; }
    public JButton getBtnCesta() { return btnCesta; }
    public JButton getBtnFinalizar() { return btnFinalizar; }
    public JButton getBtnGuardar() { return btnGuardar; }
    public JButton getBtnVolver() { return btnVolver; }
    public String getNombre() { return txtNombre.getText(); }
    public String getPrecio() { return txtPrecio.getText(); }
    public String getStock() { return txtStock.getText(); }
}