package tienda.controlador;

import javax.swing.*;
import tienda.modelo.Producto;
import tienda.service.ArchivoServicio;
import java.util.List;

public class GuardarDatos extends SwingWorker<Boolean, Void> {
    private List<Producto> lista;

    public GuardarDatos(List<Producto> lista) {
        this.lista = lista;
    }

    @Override
    protected Boolean doInBackground() throws Exception {
        ArchivoServicio.guardarProductos(lista);
        return true;
    }
}