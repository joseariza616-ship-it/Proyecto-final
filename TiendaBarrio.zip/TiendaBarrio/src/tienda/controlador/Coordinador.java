package tienda.controlador;

import java.util.ArrayList;
import java.util.List; 
import javax.swing.*;
import java.awt.*;
import tienda.modelo.*;
import tienda.vista.*;
import tienda.service.ArchivoServicio;

public class Coordinador {
    private VentanaLogin login;
    private List<Producto> inventario;
    private List<Venta> registroVentas;
    private List<ElementoCesta> cestaActual;
    private double subtotalCesta = 0;

    //Clase interna para gestionar la cesta y devoluciones parciales
    private class ElementoCesta {
        String nombre;
        int cantidad;
        double precioTotal;
        int filaOriginal;

        ElementoCesta(String n, int c, double p, int f) {
            this.nombre = n; 
            this.cantidad = c; 
            this.precioTotal = p; 
            this.filaOriginal = f;
        }
        
        @Override
        public String toString() { 
            return String.format("%-15s x%d ($%.2f)", nombre, cantidad, precioTotal); 
        }
    }

    public Coordinador(VentanaLogin login) {
        this.login = login;
        this.inventario = new ArrayList<>();
        this.registroVentas = new ArrayList<>();
        this.cestaActual = new ArrayList<>();
        cargarDatos();
        this.login.getBtnEntrar().addActionListener(e -> validarAcceso());
    }

    private void cargarDatos() {
        try { 
            inventario = ArchivoServicio.cargarProductos(); 
        } catch (Exception e) { 
            inventario = new ArrayList<>(); 
        }
    }

    private void validarAcceso() {
        if (login.getUsuario().equals("tendero") && login.getClave().equals("123")) {
            login.dispose();
            abrirMenu();
        } else {
            JOptionPane.showMessageDialog(login, "Datos incorrectos");
        }
    }

    private void abrirMenu() {
        VentanaMenu menu = new VentanaMenu();
        menu.getBtnVer().addActionListener(e -> { menu.dispose(); abrirTienda(true); });
        menu.getBtnGestion().addActionListener(e -> { menu.dispose(); abrirTienda(false); });
        menu.getBtnReporte().addActionListener(e -> mostrarReporteVertical());
        menu.getBtnCerrarSesion().addActionListener(e -> { menu.dispose(); login.setVisible(true); });
        menu.setVisible(true);
    }

    private void abrirTienda(boolean soloLectura) {
        VentanaPrincipal vista = new VentanaPrincipal();
        vista.configurarModo(soloLectura);
        actualizarTabla(vista);

        if (soloLectura) {
            //Ventas
            vista.getBtnCesta().addActionListener(e -> {
                int fila = vista.getTablaInventario().getSelectedRow();
                if (fila != -1) {
                    int stockDisp = (int) vista.getModeloTabla().getValueAt(fila, 3);
                    String cantStr = JOptionPane.showInputDialog(vista, "Cantidad a comprar:", "1");
                    try {
                        int cant = Integer.parseInt(cantStr);
                        if (cant > 0 && cant <= stockDisp) {
                            String nombre = (String) vista.getModeloTabla().getValueAt(fila, 1);
                            double precio = (double) vista.getModeloTabla().getValueAt(fila, 2);
                            
                            cestaActual.add(new ElementoCesta(nombre, cant, precio * cant, fila));
                            subtotalCesta += (precio * cant);

                            vista.getModeloTabla().setValueAt(stockDisp - cant, fila, 3);
                            inventario.get(fila).setStock(stockDisp - cant);
                        } else { 
                            JOptionPane.showMessageDialog(vista, "Stock insuficiente o cantidad inválida."); 
                        }
                    } catch (Exception ex) {}
                }
            });

            vista.getBtnFinalizar().addActionListener(e -> {
                if (cestaActual.isEmpty()) return;
                String[] opciones = {"Pagar", "Quitar de Cesta", "Cancelar"};
                int sel = JOptionPane.showOptionDialog(vista, 
                        "Subtotal: $" + String.format("%.2f", subtotalCesta), 
                        "Cesta de Compras", 0, JOptionPane.QUESTION_MESSAGE, null, opciones, opciones[0]);
                
                if (sel == 0) {
                    registroVentas.add(new Venta(cestaActual.toString(), cestaActual.size(), subtotalCesta));
                    cestaActual.clear(); 
                    subtotalCesta = 0;
                    JOptionPane.showMessageDialog(vista, "Venta Exitosa.");
                } else if (sel == 1) { 
                    eliminarYRestaurarStock(vista); 
                }
            });
        } else {
            //Reabastecimiento
            vista.getBtnCesta().addActionListener(e -> {
                int fila = vista.getTablaInventario().getSelectedRow();
                if (fila != -1) {
                    String nombre = (String) vista.getModeloTabla().getValueAt(fila, 1);
                    String addStr = JOptionPane.showInputDialog(vista, "Sumar stock a: " + nombre, "10");
                    try {
                        int cantidadAñadir = Integer.parseInt(addStr);
                        if (cantidadAñadir > 0) {
                            int stockActual = (int) vista.getModeloTabla().getValueAt(fila, 3);
                            int nuevoStock = stockActual + cantidadAñadir;
                            vista.getModeloTabla().setValueAt(nuevoStock, fila, 3);
                            inventario.get(fila).setStock(nuevoStock);
                            JOptionPane.showMessageDialog(vista, "Stock actualizado.");
                        }
                    } catch (Exception ex) {}
                }
            });

            //Añadir nuevo producto
            vista.getBtnAgregar().addActionListener(e -> {
                try {
                    String nom = vista.getNombre();
                    double pre = Double.parseDouble(vista.getPrecio());
                    int sto = Integer.parseInt(vista.getStock());
                    if(!nom.isEmpty()) {
                        Producto nuevo = new ProductoUnidad(inventario.size() + 1, nom, pre, sto);
                        inventario.add(nuevo);
                        actualizarTabla(vista);
                        vista.limpiarCampos();
                    }
                } catch (Exception ex) {
                    JOptionPane.showMessageDialog(vista, "Datos incorrectos.");
                }
            });

            vista.getBtnGuardar().addActionListener(e -> {
                JOptionPane.showMessageDialog(vista, "Datos guardados en sistema.");
            });
        }

        vista.getBtnVolver().addActionListener(e -> { vista.dispose(); abrirMenu(); });
        vista.setVisible(true);
    }

    private void eliminarYRestaurarStock(VentanaPrincipal vista) {
        if (cestaActual.isEmpty()) return;
        
        StringBuilder sb = new StringBuilder("Seleccione el producto para quitar unidades:\n");
        for (int i = 0; i < cestaActual.size(); i++) {
            sb.append(i).append(". ").append(cestaActual.get(i)).append("\n");
        }
        
        String inputIdx = JOptionPane.showInputDialog(vista, sb.toString());
        
        try {
            int idx = Integer.parseInt(inputIdx);
            if (idx >= 0 && idx < cestaActual.size()) {
                ElementoCesta item = cestaActual.get(idx);
                
                String inputCant = JOptionPane.showInputDialog(vista, 
                    "¿Cuántas unidades desea quitar de [" + item.nombre + "]?\n" +
                    "Cantidad en cesta: " + item.cantidad, "1");
                
                int cantAQuitar = Integer.parseInt(inputCant);

                if (cantAQuitar > 0 && cantAQuitar <= item.cantidad) {
                    double precioUnitario = item.precioTotal / item.cantidad;
                    double montoARestar = precioUnitario * cantAQuitar;

                    item.cantidad -= cantAQuitar;
                    item.precioTotal -= montoARestar;
                    subtotalCesta -= montoARestar;

                    int stockActual = (int) vista.getModeloTabla().getValueAt(item.filaOriginal, 3);
                    vista.getModeloTabla().setValueAt(stockActual + cantAQuitar, item.filaOriginal, 3);
                    inventario.get(item.filaOriginal).setStock(stockActual + cantAQuitar);

                    if (item.cantidad == 0) {
                        cestaActual.remove(idx);
                        JOptionPane.showMessageDialog(vista, "Producto eliminado de la cesta.");
                    } else {
                        JOptionPane.showMessageDialog(vista, "Se han retirado " + cantAQuitar + " unidades.");
                    }
                } else {
                    JOptionPane.showMessageDialog(vista, "Cantidad no permitida.");
                }
            }
        } catch (Exception e) {}
    }

    private void actualizarTabla(VentanaPrincipal vista) {
        vista.getModeloTabla().setRowCount(0);
        for (Producto p : inventario) {
            vista.getModeloTabla().addRow(new Object[]{p.getId(), p.getNombre(), p.getPrecioBase(), p.getStock()});
        }
    }

    private void mostrarReporteVertical() {
        if (registroVentas.isEmpty()) {
            JOptionPane.showMessageDialog(null, "No hay ventas registradas.");
            return;
        }

        StringBuilder sb = new StringBuilder("=== REPORTE DE VENTAS ===\n\n");
        double totalGlobal = 0;

        for (Venta v : registroVentas) {
            sb.append("FECHA: ").append(v.getFecha()).append("\n");
            sb.append("PRODUCTOS:\n");
            
            String productos = v.getNombreProducto().replace("[", "").replace("]", "");
            for (String linea : productos.split(",")) {
                sb.append("  • ").append(linea.trim()).append("\n");
            }
            
            sb.append("TOTAL: $").append(String.format("%.2f", v.getTotal())).append("\n");
            sb.append("------------------------------------------\n");
            totalGlobal += v.getTotal();
        }

        sb.append("\n>>> TOTAL RECAUDADO: $").append(String.format("%.2f", totalGlobal));

        JTextArea areaTexto = new JTextArea(sb.toString());
        areaTexto.setEditable(false);
        areaTexto.setFont(new Font("Monospaced", Font.PLAIN, 13));
        
        JScrollPane scrollPane = new JScrollPane(areaTexto);
        scrollPane.setPreferredSize(new Dimension(450, 500)); 
        
        JOptionPane.showMessageDialog(null, scrollPane, "Historial Detallado", JOptionPane.PLAIN_MESSAGE);
    }
}