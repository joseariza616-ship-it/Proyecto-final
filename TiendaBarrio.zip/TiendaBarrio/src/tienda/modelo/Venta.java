package tienda.modelo;

import java.io.Serializable;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class Venta implements Serializable {
    private String nombreProducto;
    private int cantidad;
    private double total;
    private String fecha;

    public Venta(String nombreProducto, int cantidad, double total) {
        this.nombreProducto = nombreProducto;
        this.cantidad = cantidad;
        this.total = total;
        this.fecha = LocalDateTime.now().format(DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm:ss"));
    }

    public String getNombreProducto() { return nombreProducto; }
    public int getCantidad() { return cantidad; }
    public double getTotal() { return total; }
    public String getFecha() { return fecha; }
}