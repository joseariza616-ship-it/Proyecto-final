package tienda.modelo;

import java.io.Serializable;

public abstract class Producto implements Serializable {
    private int id;
    private String nombre;
    private double precioBase;
    private int stock;

    public Producto(int id, String nombre, double precioBase, int stock) {
        this.id = id;
        this.nombre = nombre;
        this.precioBase = precioBase;
        this.stock = stock;
    }

    //Getters y Setters
    public int getId() { return id; }
    public String getNombre() { return nombre; }
    public double getPrecioBase() { return precioBase; }
    public int getStock() { return stock; }
    public void setStock(int stock) { this.stock = stock; }

    //Método abstracto para polimorfismo
    public abstract double calcularSubtotal(double cantidad);
}