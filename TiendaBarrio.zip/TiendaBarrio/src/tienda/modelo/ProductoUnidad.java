package tienda.modelo;


public class ProductoUnidad extends Producto {

    public ProductoUnidad(int id, String nombre, double precio, int stock) {
        super(id, nombre, precio, stock);
    }

    @Override
    public double calcularSubtotal(double cantidad) {
        return getPrecioBase() * cantidad;
    }
}