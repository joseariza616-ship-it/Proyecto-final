package tienda.service;

import tienda.modelo.Producto;
import java.io.*;
import java.util.ArrayList;
import java.util.List;

public class ArchivoServicio {
    private static final String NOMBRE_ARCHIVO = "inventario_tienda.dat";

    //Guardar la lista de productos
    public static void guardarProductos(List<Producto> productos) throws IOException {
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(NOMBRE_ARCHIVO))) {
            oos.writeObject(productos);
        }
    }

    //Cargar la lista de productos
    @SuppressWarnings("unchecked")
    public static List<Producto> cargarProductos() throws IOException, ClassNotFoundException {
        File archivo = new File(NOMBRE_ARCHIVO);
        if (!archivo.exists()) return new ArrayList<>();

        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(archivo))) {
            return (List<Producto>) ois.readObject();
        }
    }
}
